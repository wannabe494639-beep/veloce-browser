/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

// ublock-badware

// Important!
// Isolate from global scope
(function uBOL_cssGenericImport() {

const lowlyGeneric = new Map(/* 53 */[[25377,"html[lang] > body.ishome > div.adult + main.main"],[62925,".buttonautocl"],[29781,"body.user-clicked[style=\"cursor: auto;\"] > #root > .app-container"],[59372,"body > .main-wrapper > .main-content > .intro > #checkbox-window,\nbody[data-clipboard-code] > .main-wrapper,\nbody > .main-wrapper > .main-content > .intro > .checkbox-window"],[25775,"body.wp-singular > div[id$=\"-overlay\"] > div[id$=\"-container\"] > div[class*=\"-container\"] > div[id$=\"-checkbox-window\"],\n.wp-singular > div[data-sm][style*=\"2147483647\"] > iframe[style*=\"100%\"][allow*=\"clipboard-write\"],\n.wp-singular > iframe[srcdoc][allowfullscreen][allow*=\"clipboard-write\"][style*=\"2147483647\"]"],[23774,"div.card > div#cbRow.checkbox-row[onclick=\"startVerify()\"]"],[40573,"html > #bw-cf-root"],[54745,"body > .page > #mainVerifyRow,\nbody > .page > .verify-row"],[49696,"html.canvas > body.wp-singular + div[popover=\"manual\"]"],[53167,"#uc-cf-overlay"],[42259,"#turnstile[onclick=\"handleClick()\"]"],[44425,"body > .content-wrapper > .cf-wrap"],[19011,"#cmdTextDisplay,\n#cmdTextDisplay ~ *"],[23432,".btn-primary[onclick=\"showVerification()\"]"],[45503,".cta-button[onclick=\"openUpdateModal()\"]"],[51063,"#mainBtn[onclick=\"startVerify()\"]"],[59950,"#ipBar + .main"],[14275,".cjs-container > #checkbox-window,\n.cjs-container > #verify-window"],[46919,"body > .cf-root"],[9046,"body > div.mw[role=\"main\"] > .mc"],[8752,"html > #nochain-demo-frame:not(body)"],[36518,"html > #nc-cover:not(body)"],[40914,"#cf-challenge-root"],[43454,"html > #bw-rc-host"],[56637,"html > .cfmd-shadow-host"],[47710,"body > .cf-page-wrap"],[48940,"html[data-page=\"macos-download\"] > body[data-platform=\"macos\"] > .app_wrap"],[49842,"div.grid[aria-hidden=\"true\"]:not([id]):not([style]) + main:not([class]):not([id]):not([style]) ~ div[style=\"position: fixed; inset: 0px; z-index: 2147483647;\"]:not([class]):not([id])"],[17518,"body[data-m][style] > footer ~ #plcontent > #plgate"],[13670,"#plcontent > #bw-cf-root"],[41838,"body.glue-body > #cf-modal-overlay"],[38183,"body > #rcOverlay > #rcCard"],[47790,"html[lang] > body:not([class]):not([id]):not([style]) > div.background-container > div.container > div.captcha-box,\nbody > div[data-captcha-enable=\"true\"] > div.cleanslate[id^=\"google-captcha-\"] > div.captcha-box"],[35240,"html[lang] > body.startnew > div#sections > section#section_uname"],[47874,"html[lang] > body:not([style]) > div.captchaBody"],[5312,"html[lang] > body#body > * > div.cv-xwrapper > div.cvc > div.cv-inner"],[8320,"html[lang] > body#body > * > div.cvh.BlockClicksActivityBusy"],[15418,"html#html[sti][vic][lang] > body#allbody"],[58039,"html > body > div.container.m-p > #checkbox-window.checkbox-window,\nhtml > body > div.container > form#unsubscribe-form[onsubmit=\"submitUnsubscribeForm(event)\"]"],[27111,".fkrc-verifywin-window"],[32034,".fkrc-checkbox-window"],[40698,"html[lang] > body:not([class]):not([id]):not([style]) > div.container > div.recaptcha-box"],[27543,"body > .security-container[style=\"opacity: 1; transform: translateY(0px);\"]"],[59834,"html > body.hold-transition.theme-primary.bg-img[style^=\"background-image\"][style*=\"wallpaperaccess.com\"][style*=\"background-repeat\"][style*=\"background-size\"]"],[30528,"html > body > div.content > dl > dd.dd1 > div.min_sider > form#form1[action=\"unsubscribe.php\"]"],[56762,"html > body.body > div.container > div.content > form > table.optoutForm"],[31102,"html[data-scrapbook-source][data-scrapbook-create][data-scrapbook-title] > body.no-js > div.main-wrapper[role=\"main\"] > div.main-content"],[37584,"html > #__cf_challenge_host__"],[50662,".header-fix-tester-container"],[16386,"body > div.captcha-container > div.captcha-card"],[65239,"#hero a[download=\"Unicore.zip\"],\n#hero + div.marquee-wrap + section#games + section#features + #download"],[19871,"#download a[download=\"Unicore.zip\"]"],[37978,"body > .wrapper > .card-box > #step-1"]]);
const highlyGeneric = /* 0 */"";
const exceptions = /* 0 */[];
const hostnames = /* 0 */[];
const hasEntities = false;

self.genericSelectorMaps = self.genericSelectorMaps ?? [];
self.genericSelectorMaps.push(lowlyGeneric);
self.genericDetails = self.genericDetails ?? [];
self.genericDetails.push({ highlyGeneric, exceptions, hostnames, hasEntities });

})();

/******************************************************************************/
